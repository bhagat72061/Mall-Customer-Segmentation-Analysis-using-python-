# Mall Customer Segmentation Analysis


```python
# Conclusion :-> How to group customers based on their behaviours usning K-Mean Clustering
#                This is a variable technique used by business to targrting & marketing optimized services & improve cutomer satisfaction
```


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
# to make sure all columns have similar importance { income = 100000, 25000,... but member year = 2,4,1...}
# scale the features
# scaller = StandardScaler()
# df_scaled= scaler.fit_transform(df)
# mean=0,  standard deviation =1
# making them easier for the algorithn to handle

# convert back to adtaframe
# df_scaled= pd.DataFrame(df_scaled, columsn= df.columns)
```


```python
from sklearn.preprocessing import StandardScaler
```


```python
# suppress warnings for cleaner output
```


```python
import warnings
warnings.filterwarnings("ignore")
```


```python
df= pd.read_csv("mall_Customers.csv")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Annual Income (k$)</th>
      <th>Spending Score (1-100)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Male</td>
      <td>19</td>
      <td>15</td>
      <td>39</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Male</td>
      <td>21</td>
      <td>15</td>
      <td>81</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Female</td>
      <td>20</td>
      <td>16</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Female</td>
      <td>23</td>
      <td>16</td>
      <td>77</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Female</td>
      <td>31</td>
      <td>17</td>
      <td>40</td>
    </tr>
  </tbody>
</table>
</div>




```python
# df.rename(columns={"wrong_column_name" : "new_clm_name"}, implace = true)
```


```python
df.shape
```




    (200, 5)




```python
df.info()
# df.dtypes
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 200 entries, 0 to 199
    Data columns (total 5 columns):
     #   Column                  Non-Null Count  Dtype 
    ---  ------                  --------------  ----- 
     0   CustomerID              200 non-null    int64 
     1   Gender                  200 non-null    object
     2   Age                     200 non-null    int64 
     3   Annual Income (k$)      200 non-null    int64 
     4   Spending Score (1-100)  200 non-null    int64 
    dtypes: int64(4), object(1)
    memory usage: 7.9+ KB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CustomerID</th>
      <th>Age</th>
      <th>Annual Income (k$)</th>
      <th>Spending Score (1-100)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>200.000000</td>
      <td>200.000000</td>
      <td>200.000000</td>
      <td>200.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>100.500000</td>
      <td>38.850000</td>
      <td>60.560000</td>
      <td>50.200000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>57.879185</td>
      <td>13.969007</td>
      <td>26.264721</td>
      <td>25.823522</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>18.000000</td>
      <td>15.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>50.750000</td>
      <td>28.750000</td>
      <td>41.500000</td>
      <td>34.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>100.500000</td>
      <td>36.000000</td>
      <td>61.500000</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>150.250000</td>
      <td>49.000000</td>
      <td>78.000000</td>
      <td>73.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>200.000000</td>
      <td>70.000000</td>
      <td>137.000000</td>
      <td>99.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    CustomerID                0
    Gender                    0
    Age                       0
    Annual Income (k$)        0
    Spending Score (1-100)    0
    dtype: int64




```python
df.drop(["CustomerID"],axis=1, inplace=True)
#error because i run this command again, 
#that column has already dropped when i run this command first time
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    Cell In[61], line 1
    ----> 1 df.drop(["CustomerID"],axis=1, inplace=True)
          2 #error because i run this command again, 
          3 #that column has already dropped when i run this command first time
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\frame.py:5581, in DataFrame.drop(self, labels, axis, index, columns, level, inplace, errors)
       5433 def drop(
       5434     self,
       5435     labels: IndexLabel | None = None,
       (...)
       5442     errors: IgnoreRaise = "raise",
       5443 ) -> DataFrame | None:
       5444     """
       5445     Drop specified labels from rows or columns.
       5446 
       (...)
       5579             weight  1.0     0.8
       5580     """
    -> 5581     return super().drop(
       5582         labels=labels,
       5583         axis=axis,
       5584         index=index,
       5585         columns=columns,
       5586         level=level,
       5587         inplace=inplace,
       5588         errors=errors,
       5589     )
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\generic.py:4788, in NDFrame.drop(self, labels, axis, index, columns, level, inplace, errors)
       4786 for axis, labels in axes.items():
       4787     if labels is not None:
    -> 4788         obj = obj._drop_axis(labels, axis, level=level, errors=errors)
       4790 if inplace:
       4791     self._update_inplace(obj)
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\generic.py:4830, in NDFrame._drop_axis(self, labels, axis, level, errors, only_slice)
       4828         new_axis = axis.drop(labels, level=level, errors=errors)
       4829     else:
    -> 4830         new_axis = axis.drop(labels, errors=errors)
       4831     indexer = axis.get_indexer(new_axis)
       4833 # Case for non-unique axis
       4834 else:
    

    File ~\AppData\Local\Programs\Python\Python312\Lib\site-packages\pandas\core\indexes\base.py:7070, in Index.drop(self, labels, errors)
       7068 if mask.any():
       7069     if errors != "ignore":
    -> 7070         raise KeyError(f"{labels[mask].tolist()} not found in axis")
       7071     indexer = indexer[~mask]
       7072 return self.delete(indexer)
    

    KeyError: "['CustomerID'] not found in axis"



```python
# use one hot encoding for the gender column
df= pd.get_dummies(df, columns=["Gender"], drop_first=False)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Gender</th>
      <th>Age</th>
      <th>Annual Income (k$)</th>
      <th>Spending Score (1-100)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Male</td>
      <td>19</td>
      <td>15</td>
      <td>39</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Male</td>
      <td>21</td>
      <td>15</td>
      <td>81</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Female</td>
      <td>20</td>
      <td>16</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Female</td>
      <td>23</td>
      <td>16</td>
      <td>77</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Female</td>
      <td>31</td>
      <td>17</td>
      <td>40</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(1,figsize=(15,6))
n=0;
for x in ["Age", "Annual Income (k$)", "Spending Score (1-100)"]:
    n+=1
    plt.subplot(1,3,n)
    plt.subplots_adjust(hspace=0.5, wspace= 0.5)
    sns.distplot(df[x], bins=20)
    plt.title("DistPlot of{}".format(x))
plt.show()

#here warning came but after imopoting warning and using that, and re run this code warning suppressed
```


    
![png](output_16_0.png)
    



```python
plt.figure(figsize=(15,5))
sns.countplot(y="Gender", data=df)
plt.show()
```


    
![png](output_17_0.png)
    



```python
plt.figure(1,figsize=(15,6))
n=0;
for cols in ["Age", "Annual Income (k$)", "Spending Score (1-100)"]:
    n+=1
    plt.subplot(1,3,n)
    plt.subplots_adjust(hspace=0.5, wspace= 0.5)
    sns.violinplot(x= cols, y="Gender", data=df)
    plt.ylabel("gender" if n==1 else "")
    plt.title("Voilin Plot")
plt.show()
```


    
![png](output_18_0.png)
    



```python
age_18_25= df.Age[(df.Age>=18) & (df.Age<=25)]
age_26_35= df.Age[(df.Age>=26) & (df.Age<=35)]
age_36_45= df.Age[(df.Age>=36) & (df.Age<=45)]
age_46_55= df.Age[(df.Age>=46) & (df.Age<=55)]
age_55above= df.Age[df.Age>=56]

agex= ["18-25","26-35","36-45","46-55","55+"]
agey= [len(age_18_25.values),len(age_26_35.values),len(age_36_45.values),len(age_46_55.values),len(age_55above.values)]
plt.figure(figsize=(15,6))
sns.barplot(x=agex, y=agey, palette="mako")
plt.title("Nummbers of Customer and Age")
plt.xlabel("Age")
plt.ylabel("Number of Customer")
plt.show()

# here also warning came something about .... i do not remember but after re run warning got suppressed because importing warning and use
```


    
![png](output_19_0.png)
    



```python
sns.relplot(x="Annual Income (k$)", y="Spending Score (1-100)", data=df)
```




    <seaborn.axisgrid.FacetGrid at 0x28f52e39ee0>




    
![png](output_20_1.png)
    



```python
pip install scikit-learn
```

    Requirement already satisfied: scikit-learn in c:\users\bhaga\appdata\local\programs\python\python312\lib\site-packages (1.5.2)
    Requirement already satisfied: numpy>=1.19.5 in c:\users\bhaga\appdata\local\programs\python\python312\lib\site-packages (from scikit-learn) (2.1.1)
    Requirement already satisfied: scipy>=1.6.0 in c:\users\bhaga\appdata\local\programs\python\python312\lib\site-packages (from scikit-learn) (1.14.1)
    Requirement already satisfied: joblib>=1.2.0 in c:\users\bhaga\appdata\local\programs\python\python312\lib\site-packages (from scikit-learn) (1.4.2)
    Requirement already satisfied: threadpoolctl>=3.1.0 in c:\users\bhaga\appdata\local\programs\python\python312\lib\site-packages (from scikit-learn) (3.5.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
# using elbow method to find the optimal number of clusters
#wcss= within clusters sum of squares
# less the wcss more dense the points in scatter plot
```


```python
x1= df.loc[:,["Age","Spending Score (1-100)"]].values

from sklearn.cluster import KMeans
wcss= []
for k in range(1,11):
    kmeans= KMeans(n_clusters=k, init="k-means++")
    kmeans.fit(x1)
    wcss.append(kmeans.inertia_)
plt.grid()
plt.plot(range(1,11), wcss, linewidth=2, color="red", marker="8")
plt.xlabel("K Value")
plt.ylabel("WCSS")
plt.show()
```


    
![png](output_23_0.png)
    



```python
kmeans= KMeans(n_clusters=4)
label= kmeans.fit_predict(x1)
print(label)
```

    [2 0 1 0 2 0 1 0 1 0 1 0 1 0 1 0 2 2 1 0 2 0 1 0 1 0 1 2 1 0 1 0 1 0 1 0 1
     0 1 0 3 0 3 2 1 2 3 2 2 2 3 2 2 3 3 3 3 3 2 3 3 2 3 3 3 2 3 3 2 2 3 3 3 3
     3 2 3 2 2 3 3 2 3 3 2 3 3 2 2 3 3 2 3 2 2 2 3 2 3 2 2 3 3 2 3 2 3 3 3 3 3
     2 2 2 2 2 3 3 3 3 2 2 2 0 2 0 3 0 1 0 1 0 2 0 1 0 1 0 1 0 1 0 2 0 1 0 3 0
     1 0 1 0 1 0 1 0 1 0 1 0 3 0 1 0 1 0 1 0 1 2 1 0 1 0 1 0 1 0 1 0 1 0 1 0 2
     0 1 0 1 0 1 0 1 0 1 0 1 0 1 0]
    


```python
print(kmeans.cluster_centers_)
```

    [[30.1754386  82.35087719]
     [43.29166667 15.02083333]
     [27.61702128 49.14893617]
     [55.70833333 48.22916667]]
    


```python
plt.scatter(x1[:,0],x1[:,1], c= kmeans.labels_, cmap= "rainbow")
plt.scatter(kmeans.cluster_centers_[:,0], kmeans.cluster_centers_[:,1], color="black")
plt.title("Clusters of Customers")
plt.xlabel("Age")
plt.ylabel("Spending Score (1-100)")
plt.show()
```


    
![png](output_26_0.png)
    



```python
x2= df.loc[:,["Annual Income (k$)","Spending Score (1-100)"]].values

wcss= []
for k in range(1,11):
    kmeans= KMeans(n_clusters=k, init="k-means++")
    kmeans.fit(x2)
    wcss.append(kmeans.inertia_)
plt.grid()
plt.plot(range(1,11), wcss, linewidth=2, color="green", marker="8")
plt.xlabel("K Value")
plt.ylabel("WCSS")
plt.show()
```


    
![png](output_27_0.png)
    



```python
kmeans= KMeans(n_clusters=5)
label= kmeans.fit_predict(x2)
print(label)
```

    [4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4 2 4
     2 4 2 4 2 4 0 4 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
     0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
     0 0 0 0 0 0 0 0 0 0 0 0 1 3 1 0 1 3 1 3 1 0 1 3 1 3 1 3 1 3 1 0 1 3 1 3 1
     3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3
     1 3 1 3 1 3 1 3 1 3 1 3 1 3 1]
    


```python
print(kmeans.cluster_centers_)
```

    [[55.2962963  49.51851852]
     [86.53846154 82.12820513]
     [25.72727273 79.36363636]
     [88.2        17.11428571]
     [26.30434783 20.91304348]]
    


```python
plt.scatter(x2[:,0],x2[:,1], c= kmeans.labels_, cmap= "rainbow")
plt.scatter(kmeans.cluster_centers_[:,0], kmeans.cluster_centers_[:,1], color="black")
plt.title("Clusters of Customers")
plt.xlabel("Annual Income (k$)")
plt.ylabel("Spending Score (1-100)")
plt.show()
```


    
![png](output_30_0.png)
    



```python
x3= df.iloc[:,1:]
wcss= []
for k in range(1,11):
    kmeans= KMeans(n_clusters=k, init="k-means++")
    kmeans.fit(x3)
    wcss.append(kmeans.inertia_)
plt.grid()
plt.plot(range(1,11), wcss, linewidth=2, color="green", marker="8")
plt.xlabel("K Value")
plt.ylabel("WCSS")
plt.show()
```


    
![png](output_31_0.png)
    



```python
kmeans= KMeans(n_clusters=6)
label= kmeans.fit_predict(x3)
print(label)
```

    [0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0 4 0
     4 0 4 2 4 0 4 0 4 2 5 5 5 2 5 5 2 2 2 2 2 5 2 2 5 2 2 2 5 2 2 5 5 2 2 2 2
     2 5 2 5 5 2 2 5 2 2 5 2 2 5 5 2 2 5 2 5 5 5 2 5 2 5 5 2 2 5 2 5 2 2 2 2 2
     5 5 5 5 5 2 2 2 2 5 5 5 1 5 1 5 1 3 1 3 1 5 1 3 1 3 1 3 1 3 1 5 1 3 1 3 1
     3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3 1 3
     1 3 1 3 1 3 1 3 1 3 1 3 1 3 1]
    


```python
print(kmeans.cluster_centers_)
```

    [[44.31818182 25.77272727 20.27272727]
     [32.69230769 86.53846154 82.12820513]
     [56.34090909 53.70454545 49.38636364]
     [41.64705882 88.73529412 16.76470588]
     [25.52173913 26.30434783 78.56521739]
     [27.31578947 57.5        48.44736842]]
    


```python
 clusters= kmeans.fit_predict(x3)
df["label"]= clusters

from mpl_toolkits.mplot3d import Axes3D

fig=plt.figure(figsize=(20,10))
ax= fig.add_subplot(111, projection="3d")
ax.scatter(df.Age[df.label==0],df["Annual Income (k$)"][df.label==0], df["Spending Score (1-100)"][df.label==0], color="red", s=60)
ax.scatter(df.Age[df.label==1],df["Annual Income (k$)"][df.label==1], df["Spending Score (1-100)"][df.label==1], color="blue", s=60)
ax.scatter(df.Age[df.label==2],df["Annual Income (k$)"][df.label==2], df["Spending Score (1-100)"][df.label==2], color="green", s=60)
ax.scatter(df.Age[df.label==3],df["Annual Income (k$)"][df.label==3], df["Spending Score (1-100)"][df.label==3], color="cyan", s=60)
ax.scatter(df.Age[df.label==4],df["Annual Income (k$)"][df.label==4], df["Spending Score (1-100)"][df.label==4], color="yellow", s=60)
ax.view_init(30,185)

plt.xlabel("Age")
plt.ylabel("Annual Income (k$)")
ax.set_zlabel("Spending Score (1-100)")

plt.show()
```


    
![png](output_34_0.png)
    



```python
print(df.columns)
```

    Index(['Gender', 'Age', 'Annual Income (k$)', 'Spending Score (1-100)',
           'label'],
          dtype='object')
    


```python
cluster_summary= df.groupby("label").mean()
print(cluster_summary)
```

                 Age  Annual Income (k$)  Spending Score (1-100)  Gender_Female  \
    label                                                                         
    0      42.636364          108.181818               21.272727       0.636364   
    1      24.800000           41.460000               63.700000       0.600000   
    2      44.318182           25.772727               20.272727       0.590909   
    3      53.823529           54.725490               48.980392       0.588235   
    4      32.692308           86.538462               82.128205       0.538462   
    5      39.481481           78.370370               17.555556       0.407407   
    
           Gender_Male  
    label               
    0         0.363636  
    1         0.400000  
    2         0.409091  
    3         0.411765  
    4         0.461538  
    5         0.592593  
    


```python

```
